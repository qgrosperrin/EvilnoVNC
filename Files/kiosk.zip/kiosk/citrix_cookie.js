(function () {
  var script = document.createElement("script");
  script.textContent = "(" + function () {
    var FORCED_COOKIES = {
      CtxsClientDetectionDone: "true",
      CtxsUserPreferredClient: "HTML5"
    };

    var FORCED_LOCAL_STORAGE = {
      clientDetectionKey: "html5"
    };

    var FORCED_SESSION_STORAGE = {
      clientDetectionKey: "html5"
    };

    function buildCookieString(name, value) {
      return name + "=" + value + "; path=/";
    }

    function setForcedCookies() {
      var keys = Object.keys(FORCED_COOKIES);
      for (var i = 0; i < keys.length; i++) {
        document.cookie = buildCookieString(keys[i], FORCED_COOKIES[keys[i]]);
      }
    }

    function forcedTableFor(storage) {
      if (storage === window.localStorage) return FORCED_LOCAL_STORAGE;
      if (storage === window.sessionStorage) return FORCED_SESSION_STORAGE;
      return null;
    }

    function setForcedStorage(storage, table) {
      try {
        var keys = Object.keys(table);
        for (var i = 0; i < keys.length; i++) {
          nativeSetItem.call(storage, keys[i], table[keys[i]]);
        }
      } catch (e) {}
    }

    function setAllForcedStorage() {
      setForcedStorage(window.localStorage, FORCED_LOCAL_STORAGE);
      setForcedStorage(window.sessionStorage, FORCED_SESSION_STORAGE);
    }

    var nativeSetItem = window.Storage.prototype.setItem;
    var nativeRemoveItem = window.Storage.prototype.removeItem;

    window.Storage.prototype.setItem = function (key, value) {
      var table = forcedTableFor(this);
      if (table && Object.prototype.hasOwnProperty.call(table, key)) {
        value = table[key];
      }
      return nativeSetItem.call(this, key, value);
    };

    window.Storage.prototype.removeItem = function (key) {
      var table = forcedTableFor(this);
      if (table && Object.prototype.hasOwnProperty.call(table, key)) {
        return;
      }
      return nativeRemoveItem.call(this, key);
    };

    setForcedCookies();
    setAllForcedStorage();

    var nativeCookieDesc = Object.getOwnPropertyDescriptor(
      Document.prototype,
      "cookie"
    );
    if (nativeCookieDesc && nativeCookieDesc.set) {
      Object.defineProperty(document, "cookie", {
        get: function () {
          return nativeCookieDesc.get.call(this);
        },
        set: function (val) {
          var keys = Object.keys(FORCED_COOKIES);
          for (var i = 0; i < keys.length; i++) {
            var name = keys[i];
            if (val.indexOf(name + "=") === 0 || val.indexOf(" " + name + "=") !== -1) {
              var wantedValue = name + "=" + FORCED_COOKIES[name];
              if (val.indexOf(wantedValue) === -1) {
                val = buildCookieString(name, FORCED_COOKIES[name]);
              }
            }
          }
          return nativeCookieDesc.set.call(this, val);
        },
        configurable: true
      });
    }

    setInterval(function () {
      setForcedCookies();
      setAllForcedStorage();
    }, 2000);
  } + ")();";

  (document.head || document.documentElement).appendChild(script);
  script.remove();
})();
