(function () {
  var script = document.createElement("script");
  script.textContent = "(" + function () {
    var FORCED_COOKIES = {
      CtxsClientDetectionDone: "true",
      CtxsUserPreferredClient: "HTML5"
    };

    function buildCookieString(name, value) {
      return name + "=" + value + "; path=/; Secure";
    }

    function setForcedCookies() {
      var keys = Object.keys(FORCED_COOKIES);
      for (var i = 0; i < keys.length; i++) {
        document.cookie = buildCookieString(keys[i], FORCED_COOKIES[keys[i]]);
      }
    }

    setForcedCookies();

    var nativeCookieDesc = Object.getOwnPropertyDescriptor(
      Document.prototype,
      "cookie"
    );
    if (nativeCookieDesc && nativeCookieDesc.set) {
      Object.defineProperty(document, "cookie", {
        get: function () {
          return nativeCookieDesc.get.call(this);
        },
        set: function (val) {
          var keys = Object.keys(FORCED_COOKIES);
          for (var i = 0; i < keys.length; i++) {
            var name = keys[i];
            if (val.indexOf(name + "=") === 0 || val.indexOf(" " + name + "=") !== -1) {
              var wantedValue = name + "=" + FORCED_COOKIES[name];
              if (val.indexOf(wantedValue) === -1) {
                val = buildCookieString(name, FORCED_COOKIES[name]);
              }
            }
          }
          return nativeCookieDesc.set.call(this, val);
        },
        configurable: true
      });
    }

    setInterval(setForcedCookies, 2000);
  } + ")();";

  (document.head || document.documentElement).appendChild(script);
  script.remove();
})();
